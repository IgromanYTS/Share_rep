import telebot
from telebot import types
import pandas as pd
import logging
import re
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import os
from telebot.types import BotCommand


# Инициализация бота
bot = telebot.TeleBot("7826522309:AAH5sXBfqoOoD9DvQvcG48FZWUWXvj9aR04")

# Константы для авторизации
'''ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "111"'''

users_database = {"admin": "111", "Yura": "112", "Roman": "113"}

# Состояния пользователя и авторизация
user_states = {}
user_authenticated = set()
user_authenticate = {}

# Глобальные переменные для диаметров
diameters_standard = []
diameters_nonstandard = []
data_main = None
data_minimum = None


# Функция для загрузки данных из Excel
def load_data():
    global data_main, data_minimum
    main_file_path = "/mnt/share/18.10.2024.xlsx"
    minimum_file_path = "/mnt/share/Orders.xlsx"
    try:
        data_main = pd.read_excel(main_file_path).dropna(how="all")
        data_minimum = pd.read_excel(minimum_file_path).dropna(how="all")
        print("Данные успешно загружены")
        return True
    except Exception as e:
        print("Ошибка при загрузке данных:", e)
        return False


def set_bot_commands():
    commands = [
        BotCommand("start", "Запуск бота"),
        BotCommand("check", "Перевірити замовлення"),
    ]
    bot.set_my_commands(commands)


# Извлечение диаметра из строки
def extract_diameter(nomenclature):
    match = re.search(r"(\d{3})-[^-]+$", nomenclature)
    return str(int(match.group(1))) if match else None


# Предварительная обработка данных для создания списка стандартных и нестандартных диаметров
def initialize_diameters():
    global diameters_standard, diameters_nonstandard
    if data_main is not None:
        data_filtered = data_main[
            data_main["Номенклатура"].str.startswith("Механічне ущільнення")
        ]
        diameters_all = sorted(
            {
                int(extract_diameter(n))
                for n in data_filtered["Номенклатура"]
                if extract_diameter(n)
            }
        )

        # Разделяем диаметры на стандартные (≤100) и нестандартные (>100)
        diameters_standard = sorted([d for d in diameters_all if d < 100])
        if 100 in diameters_all:
            diameters_standard.append(
                100
            )  # Добавляем 100 в конец списка стандартных диаметров
        diameters_nonstandard = sorted([d for d in diameters_all if d > 100])


# Стартовая команда /start
@bot.message_handler(commands=["start"])
def handle_start(message):
    chat_id = message.chat.id
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    start_button = types.KeyboardButton("Розпочати")
    markup.add(start_button)
    bot.send_message(
        chat_id, "Привіт! Для початку натисніть 'Розпочати'.", reply_markup=markup
    )


# Команда /check для вывода данных из файла Замовлення
@bot.message_handler(commands=["check"])
def handle_check(message):
    chat_id = message.chat.id

    # Проверяем, авторизован ли пользователь
    if chat_id not in user_authenticated:
        bot.send_message(
            chat_id,
            "Помилка: Ви повинні увійти до системи, щоб використовувати цю команду.",
        )
        return

    try:
        # Загружаем данные из файла Замовлення.xlsx
        orders_file_path = "/mnt/share/Orders.xlsx"
        if not os.path.exists(orders_file_path):
            bot.send_message(chat_id, "Файл Замовлення не знайдено.")
            return

        orders_data = pd.read_excel(orders_file_path).dropna(how="all")

        # Проверяем наличие необходимых колонок
        if (
            "Модель" not in orders_data.columns
            or "Замовлення" not in orders_data.columns
        ):
            bot.send_message(
                chat_id, "Помилка: Відсутні потрібні колонки у файлі Замовлення."
            )
            return

        # Формируем сообщение с данными
        if orders_data.empty:
            bot.send_message(chat_id, "Дані відсутні у файлі Замовлення.")
            return

        message_text = "Інформація про замовлення:\n"
        for _, row in orders_data.iterrows():
            model = row["Модель"]
            order = row["Замовлення"]
            user = row["Користувач"]
            comment = row["Коментар"] if "Коментар" in orders_data.columns else None
            message_text += f"- {model}: {order} шт (Користувач: {user})"
            if pd.notna(comment):  # Если комментарий не пустой
                message_text += f" (Коментар: {comment})"
            message_text += "\n"

        # Добавляем InlineKeyboardMarkup с кнопкой "Видалити дані"
        # markup = InlineKeyboardMarkup()
        # markup.add(InlineKeyboardButton("Видалити дані", callback_data="delete_orders"))

        # Отправляем сообщение
        # bot.send_message(chat_id, message_text, reply_markup=markup)
        bot.send_message(chat_id, message_text)  # реализация без кнопки удалить данные

    except Exception as e:
        bot.send_message(chat_id, f"Помилка при завантаженні даних: {e}")


# Обработчик нажатия кнопки "Видалити дані"
@bot.callback_query_handler(func=lambda call: call.data == "delete_orders")
def handle_delete_orders(call):
    chat_id = call.message.chat.id
    orders_file_path = "/mnt/share/Orders.xlsx"

    try:
        if os.path.exists(orders_file_path):
            # Загружаем данные из файла
            df = pd.read_excel(orders_file_path).dropna(how="all")

            # Проверяем наличие нужных колонок
            if (
                "Модель" in df.columns
                and "Замовлення" in df.columns
                and "Коментар" in df.columns
            ):
                # Очищаем данные, оставляем только шапку
                df_cleaned = df[["Модель", "Замовлення", "Коментар"]].iloc[0:0]

                # Сохраняем очищенный файл
                df_cleaned.to_excel(orders_file_path, index=False)
                bot.send_message(chat_id, "Дані та коментарі успішно видалено.")
            else:
                bot.send_message(
                    chat_id, "Помилка: Відсутні необхідні колонки для очищення."
                )
        else:
            bot.send_message(chat_id, "Файл Замовлення не знайдено.")
    except Exception as e:
        bot.send_message(chat_id, f"Помилка при очищенні файлу: {e}")


# Обработка кнопки "Розпочати"
@bot.message_handler(func=lambda message: message.text == "Розпочати")
def handle_start_button(message):
    chat_id = message.chat.id
    if chat_id in user_authenticated:
        show_diameter_options(message)
    else:
        user_states[chat_id] = "enter_credentials"
        bot.send_message(
            chat_id, "Введіть логін та пароль через пробіл (наприклад, login password):"
        )


# Проверка учетных данных
"""def is_valid_credentials(username, password):
    return username == ADMIN_USERNAME and password == ADMIN_PASSWORD"""


def is_valid_credentials(username, password):
    return users_database.get(username) == password


# Обработка ввода учетных данных
@bot.message_handler(
    func=lambda message: user_states.get(message.chat.id) == "enter_credentials"
)
def handle_credentials(message):
    chat_id = message.chat.id
    user_input = message.text.split()
    """if len(user_input) == 2 and is_valid_credentials(user_input[0], user_input[1]):
        user_authenticated.add(chat_id)
        show_diameter_options(message)
    else:
        bot.send_message(chat_id, "Помилка: Невірні дані. Спробуйте ще раз.")"""
    if len(user_input) == 2:
        username, password = user_input
        if is_valid_credentials(username, password):
            user_authenticate[chat_id] = username
            user_authenticated.add(chat_id)
            bot.send_message(chat_id, f"Ласкаво просимо {username}!")
            show_diameter_options(message)
        else:
            bot.send_message(chat_id, "Помилка: Невірні дані. Спробуйте ще раз.")
    else:
        bot.send_message(chat_id, "Помилка: Введіть логін та пароль через пробіл")


# Функция для показа списка диаметров
def show_diameter_options(message):
    chat_id = message.chat.id
    if diameters_standard or diameters_nonstandard:
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        for diameter in diameters_standard:
            markup.add(types.KeyboardButton(f"Діаметр {diameter}"))

        if diameters_nonstandard:
            markup.add(types.KeyboardButton("Нестандарт"))

        bot.send_message(chat_id, "Виберіть діаметр:", reply_markup=markup)
        user_states[chat_id] = "choose_diameter"
    else:
        bot.send_message(chat_id, "Помилка: Не вдалося завантажити дані.")


# Обработка выбора диаметра или кнопки "Нестандарт"
@bot.message_handler(
    func=lambda message: user_states.get(message.chat.id) == "choose_diameter"
)
def handle_diameter_selection(message):
    chat_id = message.chat.id
    selected_text = message.text

    if selected_text == "Нестандарт":
        show_nonstandard_diameters(chat_id)
    elif selected_text.startswith("Діаметр"):
        selected_diameter = selected_text.split()[-1]
        show_model_buttons(chat_id, selected_diameter)
    else:
        bot.send_message(chat_id, "Помилка: Невірний вибір.")


# Функция для показа нестандартных диаметров
def show_nonstandard_diameters(chat_id):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    for diameter in diameters_nonstandard:
        markup.add(types.KeyboardButton(f"Діаметр {diameter}"))
    markup.add(types.KeyboardButton("Назад"))

    bot.send_message(chat_id, "Оберіть нестандартний діаметр:", reply_markup=markup)
    user_states[chat_id] = "choose_nonstandard_diameter"


# Функция для показа кнопок моделей
def show_model_buttons(chat_id, diameter):
    # Use global variable data_main directly
    if data_main is None:
        bot.send_message(chat_id, "Помилка: не вдалося завантажити дані.")
        return
    
    print("DataFrame после загрузки (data_minimum):")
    print(data_minimum.head())

    if "Номенклатура" not in data_main.columns or "Кількість" not in data_main.columns:
        bot.send_message(chat_id, "Ошибка: Отсутствуют необходимые столбцы в данных.")
        print("Доступные столбцы:", data_main.columns)
        return

    # Filter by the selected diameter
    data_filtered = data_main[
        (data_main["Номенклатура"].str.startswith("Механічне ущільнення"))
        & (data_main["Номенклатура"].apply(lambda x: extract_diameter(x) == diameter))
    ]

    if data_filtered.empty:
        bot.send_message(chat_id, f"Моделей для діаметра {diameter} не знайдено.")
        print("Ошибка: После фильтрации данные пусты.")
        return

    if not data_filtered.empty:
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        for _, row in data_filtered.iterrows():
            nomenclature = row["Номенклатура"]
            quantity = row["Кількість"]
            min_quantity = data_minimum[data_minimum["Номенклатура"] == nomenclature][
                "Мінімум"
            ]
            min_quantity = min_quantity.iloc[0] if not min_quantity.empty else None
            if min_quantity is not None and quantity < min_quantity:
                nomenclature = f"⚠️ {nomenclature}"
            markup.add(types.KeyboardButton(nomenclature))
        markup.add(types.KeyboardButton("Назад"))

        bot.send_message(
            chat_id, f"Оберіть модель для діаметра {diameter}:", reply_markup=markup
        )
        user_states[chat_id] = "choose_model"
    else:
        bot.send_message(chat_id, f"Моделей для діаметра {diameter} не знайдено.")


# Обработка выбора нестандартного диаметра
@bot.message_handler(
    func=lambda message: user_states.get(message.chat.id)
    == "choose_nonstandard_diameter"
)
def handle_nonstandard_diameter_selection(message):
    chat_id = message.chat.id
    selected_text = message.text

    if selected_text == "Назад":
        show_diameter_options(message)
    elif selected_text.startswith("Діаметр"):
        selected_diameter = selected_text.split()[-1]
        user_states[chat_id] = "choose_nonstandard_model"
        show_model_buttons(chat_id, selected_diameter)
    else:
        bot.send_message(chat_id, "Помилка: Невірний вибір.")


# Обработка выбора модели
@bot.message_handler(
    func=lambda message: user_states.get(message.chat.id)
    in ["choose_model", "choose_nonstandard_diameter"]
)
def handle_model_selection(message):
    chat_id = message.chat.id
    selected_model = message.text

    clean_model = selected_model.replace("⚠️ ", "")

    if selected_model == "Назад":
        if user_states[chat_id] == "choose_nonstandard_diameter":
            show_nonstandard_diameters(chat_id)
        else:
            show_diameter_options(message)
    else:
        if data_main is None or data_minimum is None:
            bot.send_message(chat_id, "Помилка: не вдалося завантажити дані.")
            return
        model_info = data_main[
            data_main["Номенклатура"] == selected_model.replace("⚠️ ", "")
        ]
        if not model_info.empty:
            for _, row in model_info.iterrows():
                nomenclature = row["Номенклатура"]
                quantity = row["Кількість"]
                min_quantity = data_minimum[
                    data_minimum["Номенклатура"] == nomenclature
                ]["Мінімум"]
                min_quantity = min_quantity.iloc[0] if not min_quantity.empty else None
                critical_message = (
                    f"\n ⚠️ Критична кількість на складі: {quantity}"
                    if min_quantity is not None and quantity < min_quantity
                    else ""
                )
                response_text = (
                    f"Модель: {nomenclature}\n"
                    f"Кількість: {quantity}\n"
                    f"Резерв: {row['Резерв'] if pd.notna(row['Резерв']) else '-'}\n"
                    f"Вільний залишок: {row['Вільний залишок']}{critical_message}"
                )

                # Создаем InlineKeyboard с кнопкой "Редактировать"
                markup = InlineKeyboardMarkup()
                markup.add(
                    InlineKeyboardButton(
                        "Редагувати", callback_data=f"edit:{nomenclature}"
                    )
                )

                bot.send_message(chat_id, response_text, reply_markup=markup)
        else:
            bot.send_message(chat_id, "Помилка: модель не знайдена.")


def save_to_excel(
    model,
    value,
    username,
    comment=None,
):
    file_path = "/mnt/share/Orders.xlsx"

    # Если файл не существует, создаем его
    if not os.path.exists(file_path):
        df = pd.DataFrame(columns=["Модель", "Замовлення", "Користувач", "Коментар"])
    else:
        df = pd.read_excel(file_path).dropna(how="all")

    # Проверяем, есть ли уже эта модель
    """if model in df["Модель"].values:
        df.loc[df["Модель"] == model, "Замовлення"] = value
        if comment:
            df.loc[df["Модель"] == model, "Коментар"] = comment
    else:
        # Добавляем новую строку
        new_row = {"Модель": model, "Замовлення": value, "Коментар": comment}
        df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)"""

    new_row = {
        "Модель": model,
        "Замовлення": value,
        "Користувач": username,
        "Коментар": comment,
    }
    df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)

    # Сохраняем файл
    try:
        df.to_excel(file_path, index=False)
        return True
    except Exception as e:
        print("Ошибка при сохранении данных:", e)
        return False


# Обработка ввода нового значения
@bot.message_handler(
    func=lambda message: user_states.get(message.chat.id, "").startswith("edit_model:")
)
def handle_edit_value(message):
    chat_id = message.chat.id
    state = user_states.get(chat_id)
    nomenclature = state.split("edit_model:")[1]

    # Проверяем, что введено число
    if not message.text.isdigit():
        bot.send_message(chat_id, "Помилка: Введіть числове значення.")
        return

    # Сохраняем значение в состояние и запрашиваем комментарий
    new_value = int(message.text)
    user_states[chat_id] = f"edit_comment:{nomenclature}:{new_value}"
    bot.send_message(chat_id, "Введіть коментар для цього замовлення:")


# ввод коментария
@bot.message_handler(
    func=lambda message: user_states.get(message.chat.id, "").startswith(
        "edit_comment:"
    )
)
def handle_edit_comment(message):
    chat_id = message.chat.id
    state = user_states.get(chat_id)
    nomenclature, new_value = state.split("edit_comment:")[1].split(":")
    comment = message.text
    username = user_authenticate.get(chat_id, "Невідомий")

    # Сохраняем данные в Excel
    if save_to_excel(nomenclature, new_value, username, comment):
        bot.send_message(
            chat_id,
            f"Дані для моделі {nomenclature} оновлені:\n"
            f"Кількість: {new_value}\nКоментар: {comment}.",
        )
    else:
        bot.send_message(chat_id, "Помилка при збереженні даних. Спробуйте ще раз.")

    # Убираем состояние и возвращаемся в меню
    user_states.pop(chat_id, None)
    show_diameter_options(message)


# Отправка цифровой клавиатуры
def send_digit_keyboard(chat_id, text):
    markup = types.ReplyKeyboardMarkup(row_width=3, resize_keyboard=True)
    buttons = [types.KeyboardButton(str(i)) for i in range(10)]
    markup.add(*buttons, types.KeyboardButton("Закрити"))
    bot.send_message(chat_id, text, reply_markup=markup)


# Обработка выбора "Редактировать" с цифровой клавиатурой
@bot.callback_query_handler(func=lambda call: call.data.startswith("edit:"))
def handle_edit_callback(call):
    chat_id = call.message.chat.id
    nomenclature = call.data.split("edit:")[1]
    bot.send_message(chat_id, f"Введіть нове значення для моделі: {nomenclature}")
    send_digit_keyboard(chat_id, "Введіть кількість (тільки цифри):")
    user_states[chat_id] = f"edit_model:{nomenclature}"


# Обработка команды "Закрити"
@bot.message_handler(func=lambda message: message.text == "Закрити")
def handle_cancel(message):
    chat_id = message.chat.id
    user_states.pop(chat_id, None)
    bot.send_message(
        chat_id, "Редагування закрито.", reply_markup=types.ReplyKeyboardRemove()
    )
    show_diameter_options(message)


# Запуск бота
if load_data():
    initialize_diameters()
    set_bot_commands()

# Продолжение кода для обработки остальных функций...
if __name__ == "__main__":
    bot.polling()
    set_bot_commands()
